param([string]$EngineRoot = '', [ValidateSet('Current', 'SM6')][string]$Rendering = 'Current')
$ErrorActionPreference = 'Stop'
function Get-CheckEngine([string]$Association) {
    foreach ($key in @("HKLM:\SOFTWARE\EpicGames\Unreal Engine\$Association", "HKLM:\SOFTWARE\WOW6432Node\EpicGames\Unreal Engine\$Association")) {
        if (Test-Path -LiteralPath $key) {
            $candidate = (Get-ItemProperty -LiteralPath $key).InstalledDirectory
            if ($candidate -and (Test-Path -LiteralPath (Join-Path $candidate 'Engine\Binaries\Win64\UnrealEditor.exe'))) { return $candidate }
        }
    }
    $key = 'HKCU:\SOFTWARE\Epic Games\Unreal Engine\Builds'
    if (Test-Path -LiteralPath $key) {
        foreach ($property in (Get-ItemProperty -LiteralPath $key).PSObject.Properties) {
            if ($property.Name -eq $Association -and (Test-Path -LiteralPath (Join-Path $property.Value 'Engine\Binaries\Win64\UnrealEditor.exe'))) { return [string]$property.Value }
        }
    }
    $candidate = Join-Path ${env:ProgramFiles} "Epic Games\UE_$Association"
    if (Test-Path -LiteralPath (Join-Path $candidate 'Engine\Binaries\Win64\UnrealEditor.exe')) { return $candidate }
    throw 'Engine not found. Run Water-Check.ps1 with -EngineRoot followed by the UE installation folder.'
}
try {
    $projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $project = Join-Path $projectRoot 'UEBridge.uproject'
    if (!(Test-Path -LiteralPath $project -PathType Leaf)) { throw 'Extract the WaterCheck folder next to UEBridge.uproject, then double-click Water-Check.cmd inside it.' }
    if (Get-Process UnrealEditor,UnrealEditor-Cmd -ErrorAction SilentlyContinue) { throw 'Save and close Unreal Editor and the native game first. No running processes were stopped.' }
    $descriptor = Get-Content -LiteralPath $project -Raw -Encoding UTF8 | ConvertFrom-Json
    if (!$EngineRoot) { $EngineRoot = Get-CheckEngine ([string]$descriptor.EngineAssociation) }
    $editor = Join-Path $EngineRoot 'Engine\Binaries\Win64\UnrealEditor.exe'
    if (!(Test-Path -LiteralPath $editor -PathType Leaf)) { throw 'UnrealEditor.exe was not found.' }
    $runName = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8)
    $output = Join-Path $projectRoot "Saved\WaterChecks\$runName"
    New-Item -ItemType Directory -Path $output -Force | Out-Null
    $ini = Join-Path $projectRoot 'Config\DefaultEngine.ini'
    $water = Join-Path $projectRoot 'Content\Bridge\Realistic\NS_RealisticWater.uasset'
    if (!(Test-Path -LiteralPath $water -PathType Leaf)) { throw 'The current NS_RealisticWater.uasset was not found.' }
    $beforeHash = (Get-FileHash -LiteralPath $water -Algorithm SHA256).Hash
    $configHash = if (Test-Path -LiteralPath $ini) { (Get-FileHash -LiteralPath $ini -Algorithm SHA256).Hash } else { $null }
    $metadata = [ordered]@{ schema='uebridge.water-check-launcher.v1'; rendering=$Rendering; originalWaterSha256=$beforeHash; defaultEngineSha256=$configHash; editorExitCode=$null; originalWaterUnchanged=$null; configUnchanged=$null }
    $metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'launcher.json') -Encoding UTF8
    $script = Join-Path $PSScriptRoot 'water_check.py'
    $log = Join-Path $output 'WaterCheck.log'
    $arguments = @("`"$project`"", "-ExecutePythonScript=`"$script`"", "-abslog=`"$log`"", '-nosplash', '-NoSound')
    if ($Rendering -eq 'SM6') { $arguments += @('-d3d12', '-sm6') }
    $previousOutput = $env:UEBRIDGE_WATER_CHECK_OUTPUT
    try {
        $env:UEBRIDGE_WATER_CHECK_OUTPUT = $output
        Write-Host 'LEFT: current project water. RIGHT: installed engine FLIP hose.'
        Write-Host 'A separate diagnostic map will open and simulate automatically.'
        Write-Host 'Wait for shader compilation and observe the comparison. Close Unreal Editor to create the result ZIP.'
        Write-Host "Output: $output"
        $process = Start-Process -FilePath $editor -ArgumentList $arguments -Wait -PassThru
        $metadata.editorExitCode = $process.ExitCode
    } finally { $env:UEBRIDGE_WATER_CHECK_OUTPUT = $previousOutput }
    $metadata.originalWaterUnchanged = ((Get-FileHash -LiteralPath $water -Algorithm SHA256).Hash -eq $beforeHash)
    $afterConfig = if (Test-Path -LiteralPath $ini) { (Get-FileHash -LiteralPath $ini -Algorithm SHA256).Hash } else { $null }
    $metadata.configUnchanged = ($afterConfig -eq $configHash)
    $metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'launcher.json') -Encoding UTF8
    $zip = Join-Path $projectRoot "Saved\WaterChecks\WaterCheck-Result-$runName.zip"
    Compress-Archive -LiteralPath @(Get-ChildItem -LiteralPath $output -File | ForEach-Object FullName) -DestinationPath $zip
    Write-Host "Result ZIP: $zip"
    Start-Process explorer.exe -ArgumentList "/select,`"$zip`""
    $report = Join-Path $output 'report.json'
    if (!(Test-Path -LiteralPath $report)) { throw 'The editor did not run the test script. The result ZIP contains startup evidence.' }
    $result = Get-Content -LiteralPath $report -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($process.ExitCode -ne 0 -or $result.status -ne 'simulation_observed') { throw "The test did not complete normally: status=$($result.status), editor exit=$($process.ExitCode). See the result ZIP; this is not a visual pass." }
    Write-Host 'Runtime observations recorded. This confirms test execution, not water quality.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
