"""Read-only source comparison in a new UE 5.8 diagnostic map."""
import hashlib
import json
import os
from pathlib import Path
import time
import traceback
import unreal

ROOT = '/Game/Bridge/WaterChecks'
PROJECT_WATER = '/Game/Bridge/Realistic/NS_RealisticWater'
RUN = Path(os.environ['UEBRIDGE_WATER_CHECK_OUTPUT'])
RUN.mkdir(parents=True, exist_ok=True)
REPORT = {'schema': 'uebridge.water-check.v1', 'status': 'starting',
          'cases': [], 'warnings': [], 'samples': [],
          'note': 'Scene creation and active components do not certify water quality.'}
HANDLE = None
START = None
NEXT_SAMPLE = 0


def write_report():
    temporary = RUN / 'report.json.tmp'
    temporary.write_text(json.dumps(REPORT, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(RUN / 'report.json')


def required(value, message):
    if value is None or value is False:
        raise RuntimeError(message)
    return value


def optional_property(obj, name, value):
    try:
        obj.set_editor_property(name, value)
    except Exception as exc:
        REPORT['warnings'].append(name + ': ' + str(exc))


def installed_hose():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    registry.scan_paths_synchronous(['/NiagaraFluids'], True)
    candidates = sorted((a for a in registry.get_assets_by_path('/NiagaraFluids', recursive=True)
                         if str(a.asset_name).lower() == 'grid3d_flip_hose'),
                        key=lambda a: str(a.package_name))
    for candidate in candidates:
        asset = candidate.get_asset()
        if isinstance(asset, unreal.NiagaraSystem):
            return asset
    raise RuntimeError('Grid3D_FLIP_Hose was not found in Niagara Fluids. No substitute is used.')


def file_hash(relative):
    path = Path(unreal.Paths.project_dir()) / relative
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def make_scene():
    current = required(unreal.load_asset(PROJECT_WATER), 'NS_RealisticWater was not found.')
    if not isinstance(current, unreal.NiagaraSystem):
        raise RuntimeError('NS_RealisticWater is not a NiagaraSystem.')
    factory = installed_hose()
    REPORT['current_sha256'] = file_hash('Content/Bridge/Realistic/NS_RealisticWater.uasset')
    REPORT['engine_version'] = unreal.SystemLibrary.get_engine_version()
    REPORT['installed_template'] = factory.get_path_name()
    REPORT['source_controls_unchanged'] = True
    suffix = RUN.name.replace('-', '_')
    package = ROOT + '/WaterCheck_' + suffix
    level = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    required(level.new_level(package), 'Cannot create diagnostic level.')
    world = required(unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world(),
                     'Editor world is unavailable.')
    world.get_world_settings().set_editor_property('default_game_mode', unreal.GameModeBase)
    mesh = required(unreal.load_asset('/Engine/BasicShapes/Cube.Cube'), 'Engine cube is missing.')
    floor = required(actors.spawn_actor_from_class(unreal.StaticMeshActor,
                        unreal.Vector(0, 0, -50)), 'Cannot spawn the test floor.')
    floor.set_actor_label('WaterCheck_Floor')
    floor.set_editor_property('tags', [unreal.Name('collider')])
    component = floor.static_mesh_component
    component.set_mobility(unreal.ComponentMobility.STATIC)
    required(component.set_static_mesh(mesh), 'Cannot assign the test floor mesh.')
    floor.set_actor_scale3d(unreal.Vector(36, 20, 1))
    component.set_collision_profile_name('BlockAll')
    optional_property(component, 'affect_distance_field_lighting', True)
    light = required(actors.spawn_actor_from_class(unreal.DirectionalLight,
                         unreal.Vector(0, 0, 1500), unreal.Rotator(-45, -30, 0)),
                     'Cannot spawn daylight.')
    light.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
    light.light_component.set_intensity(50000.0)
    optional_property(light.light_component, 'atmosphere_sun_light', True)
    required(actors.spawn_actor_from_class(unreal.SkyAtmosphere,
             unreal.Vector(0, 0, 0)), 'Cannot spawn the sky.')
    sky = required(actors.spawn_actor_from_class(unreal.SkyLight,
                  unreal.Vector(0, 0, 600)), 'Cannot spawn the sky light.')
    sky.light_component.set_mobility(unreal.ComponentMobility.MOVABLE)
    optional_property(sky.light_component, 'real_time_capture', True)
    for label, source, x in [('LEFT_PROJECT_WATER', current, -800),
                              ('RIGHT_INSTALLED_HOSE', factory, 800)]:
        actor = required(actors.spawn_actor_from_class(unreal.NiagaraActor,
                         unreal.Vector(x, 0, 0)), 'Cannot spawn ' + label)
        actor.set_actor_label(label)
        niagara = required(actor.get_component_by_class(unreal.NiagaraComponent),
                            'Niagara component missing: ' + label)
        niagara.set_asset(source)
        optional_property(niagara, 'auto_activate', True)
        REPORT['cases'].append({'label': label, 'asset': source.get_path_name(),
                               'position_cm': [x, 0, 0], 'parameter_overrides': []})
    unreal.EditorLevelLibrary.set_level_viewport_camera_info(
        unreal.Vector(0, -2500, 1600), unreal.Rotator(-30, 90, 0))
    required(level.save_current_level(), 'Cannot save the new diagnostic map.')
    REPORT['diagnostic_map'] = package
    REPORT['status'] = 'scene_ready'
    write_report()
    unreal.log('WATER CHECK: LEFT = project water; RIGHT = installed engine hose. '
               'Source assets have not been edited. Output: ' + str(RUN))
    return level


def sample_runtime(seconds):
    world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_game_world()
    sample = {'elapsed_seconds': round(seconds, 2), 'game_world_present': world is not None}
    if world is not None:
        components = []
        for actor in unreal.GameplayStatics.get_all_actors_of_class(world, unreal.NiagaraActor):
            component = actor.get_component_by_class(unreal.NiagaraComponent)
            asset = component.get_asset()
            components.append({'actor': actor.get_name(), 'active': bool(component.is_active()),
                               'asset': asset.get_path_name() if asset is not None else None})
        sample['components'] = components
    REPORT['samples'].append(sample)
    write_report()


def fail(exc):
    REPORT['status'] = 'failed'
    REPORT['error'] = str(exc)
    REPORT['traceback'] = traceback.format_exc()
    write_report()
    unreal.log_error('WATER CHECK FAILED: ' + str(exc) + '. Report: ' + str(RUN))


def tick(_delta):
    global HANDLE, START, NEXT_SAMPLE
    try:
        if START is None:
            unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).editor_play_simulate()
            START = time.monotonic()
            REPORT['status'] = 'simulation_requested'
            write_report()
            return
        elapsed = time.monotonic() - START
        times = [5, 15, 30, 60]
        if NEXT_SAMPLE < len(times) and elapsed >= times[NEXT_SAMPLE]:
            sample_runtime(elapsed)
            NEXT_SAMPLE += 1
        if NEXT_SAMPLE == len(times):
            observed = any(s['game_world_present'] and
                len(s.get('components', [])) == len(REPORT['cases']) and
                all(c['active'] for c in s.get('components', []))
                for s in REPORT['samples'])
            REPORT['status'] = 'simulation_observed' if observed else 'simulation_not_observed'
            write_report()
            unreal.log('WATER CHECK: runtime report recorded. Compare LEFT/RIGHT; '
                       'close Unreal Editor to finish the result ZIP. '
                       'Wait until shader compilation has finished before judging the image.')
            unreal.unregister_slate_post_tick_callback(HANDLE)
            HANDLE = None
    except Exception as exc:
        fail(exc)
        if HANDLE is not None:
            unreal.unregister_slate_post_tick_callback(HANDLE)
            HANDLE = None


def main():
    global HANDLE
    try:
        make_scene()
        HANDLE = unreal.register_slate_post_tick_callback(tick)
    except Exception as exc:
        fail(exc)


if __name__ == '__main__':
    main()
