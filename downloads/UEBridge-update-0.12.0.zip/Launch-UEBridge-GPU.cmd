@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch-UEBridge-GPU.ps1" %*
if errorlevel 1 pause
