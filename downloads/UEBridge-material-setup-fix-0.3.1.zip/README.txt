UE material setup script fix 0.3.1

Save your level and stop Play. Replace setup_world_bridge.py next to the UEBridge.uproject you use.
No MOD or C++ update/rebuild is required.
In the UE console PYTHON mode execute:
exec(open("C:/your/project/setup_world_bridge.py", encoding="utf-8").read())

Fix: use unreal.Paths.project_dir(), not the unavailable project_file_path().
Success message: World bridge material ready.
Syntax and other-project guard checked in cloud. Actual UE Editor execution remains unverified.
