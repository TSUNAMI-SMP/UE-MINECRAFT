# 受領3ファイルの分析結果

## 確認できたこと

`NS_RealisticWater.uasset` は UE 5.8 のアセット。ノード接続、マテリアル設定、および主要な Rapid Iteration Parameters を読み取り専用で解析した。未対応のネイティブ領域もあるため、すべてを完全に解釈できたという意味ではない。バイナリの再保存や書き換えは行っていない。

| 水アセット内の保存値 | 値 |
|---|---|
| User.World Grid Extents | 400, 400, 500 |
| User.Num Cells Max Axis | 92 |
| User.Particles Per Cell | 8 |
| User.Pressure Iterations | 200 |
| User.Water Height | 150 |
| SpawnRate001.SpawnRate | 20,000 |
| SpawnRate001.SpawnGroup | 0 |
| Tank Spawn.Spawn Group | 0 |
| Tank Spawn.Oversampling | 10 |
| SphereLocation.Sphere Radius | 10 |
| SphereLocation.Offset | 0, 0, 0 |
| Set Particles.Velocity | 0, 0, -450 |
| 衝突対象の ActorTags | collider |

現在の水アセットの水面マテリアルは、Niagara Fluids の `M_WaterSDF_Inst` を親に持つ。Masked / Single Layer Water の設定がある。外部の親マテリアルそのものは今回の添付には含まれない。

Particle Spawn の接続は Sphere Location → Velocity → ScratchModule_01 → Kill Particles 001 → Grid3D Flip Grid Particles → Kill Particles 002。後段の Grid Particles には、水槽生成で計算された SpawnedThisFrame / TotalEmissionCells / WaterHeightZIndex が渡る。最後の Kill Particles 002 は Transient.Kill を読む。ScratchModule_01 は前フレームの SDF を参照して削除条件を作る。継続放出と水槽生成のグループが同じことは確認済みだが、外部 Grid Particles モジュールの本体と実機の実行結果を確認していないため、これだけで原因を断定してはいけない。

`User.SourcePosition` / `User.SourceLocation` / `User.SourceVelocity` / `User.SpawnRate` は、保存された公開ユーザーパラメータには存在しない。現在の C++ 側がこれらを任意に設定しようとしても、このアセットの噴出口の内部設定を制御できることは示されていない。

`DefaultEngine.ini` では `r.GenerateMeshDistanceFields=True`。INI 全体や他の設定値はこの報告書に転載しない。

`UEBridge.log` は UE 5.8.3 のエディター起動ログ。D3D12 / SM5 で、実行時 GPU は RTX 5060。NS_RealisticWater はコンパイル成功と記録されている。ゲーム内の Bridge Niagara water 診断行はない。爆発用 `M_3DGas_Base` には FXC のクラッシュ後に中間 HLSL へクロスコンパイルした記録と `internal error: l-value expected` がある。これは爆発のシェーダー診断であり、水のコンパイル失敗や黒い見た目の原因を証明するものではない。

## 結論と今回作ったもの

原因の最終確定・画質改善の実機確認には至っていない。設定を推測で次々に書き換える代わりに、元のアセットを変更せず、標準テンプレートと同じ床・昼光・空で比較する専用キットを作成した。これは修正済みアセットや高品質化の完了報告ではない。

比較に使う標準テンプレートはインストール済みエンジンから取得するため、この PC で親エミッタを変更していた場合はその影響を受ける。テストは独立マップで行い、Minecraft 地形・ネイティブゲームモード・ゲーム側の Niagara 入力値を使わない。標準 Cube の床には `collider` タグを付ける。

実機で比較テストを実行できたら、以後は「現在のアセット」「共通の描画環境」「ゲーム組み込み」のどこを調べるべきかを絞る。片側が見えるだけで、連続放出や衝突の正しさまで確定したことにはしない。
