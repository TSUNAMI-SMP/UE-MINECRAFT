@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Water-Check.ps1"
set "water_check_exit=%ERRORLEVEL%"
pause
exit /b %water_check_exit%
